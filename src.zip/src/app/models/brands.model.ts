export interface BrandsModel {
  readonly id: string;
  readonly name: string;
}
