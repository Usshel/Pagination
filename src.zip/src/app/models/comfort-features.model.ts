export interface ComfortFeaturesModel {
  readonly name: string;
  readonly id: string;
}
